<!DOCTYPE html>
<html>
<head>
<style>
</style>
</head>
<body>
<form action="insert" method="get">


<h1> form<h1>


<input type ="text" name="productname" placeholder="productname" ><br>

<input type ="text" name="price" placeholder="price" > <br>

<input type="text" name="quantity" placeholder="quantity" ><br>

<input type="submit"  name="submit" value="submit">

</form>
</body>
</html>
<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/product.blade.php ENDPATH**/ ?>