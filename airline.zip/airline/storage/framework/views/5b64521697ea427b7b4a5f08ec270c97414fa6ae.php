<html>
<head>
<title></title>
</head>
<body>
<form action="logged" method="get">

<div class="result danger">

<div class="sucess bg-info">

</div>



<?php if(Session::get('fail')): ?>
<div class="alert.alert-danger">
<?php echo e(Session::get('fail')); ?>

</div>
<?php endif; ?>
</div>
    <input type="text" name="email" placeholder="email"></br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    <input type="password" name="password" placeholder="password"><br>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    <input type="submit" value="submit">
   
 </form>
</bidy>
</html>
<?php /**PATH C:\Users\hp\laravel\Aireline_laravel\airline\resources\views/log.blade.php ENDPATH**/ ?>