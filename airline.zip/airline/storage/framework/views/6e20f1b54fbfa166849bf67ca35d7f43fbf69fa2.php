<!DOCTYPE html>
<html>
<head>
<style>
</style>
</head>
<body>
<form action="insert" method="get">
<?php echo csrf_field(); ?>
<h1> ADD MEMBERS<h1>
<input type ="text" name="member_name" placeholder="username">
<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
<input type ="text" name="email" placeholder="email">
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
<input type="text" name="address" placeholder="address">
<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
<input type="submit" value="submit">
<a href="view">viewstable</a>
</form>
</body>
</html>
<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/member.blade.php ENDPATH**/ ?>