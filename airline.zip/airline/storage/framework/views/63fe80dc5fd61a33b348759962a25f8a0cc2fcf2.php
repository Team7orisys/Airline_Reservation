<!DOCTYPE html>
<html>
<head>
<style>
</style>
</head>
<body>
<form action="/edit" method="post">

<?php echo csrf_field(); ?>
<h1> update<h1>
<input type ="hidden" name="id" placeholder="username" value="<?php echo e($data->id); ?>"><br>

<input type ="text" name="member_name" placeholder="username" value="<?php echo e($data->member_name); ?>"><br>

<input type ="text" name="email" placeholder="email" value="<?php echo e($data->email); ?>"> <br>

<input type="text" name="address" placeholder="address" value="<?php echo e($data->email); ?>"><br>

<input type="submit"  name="update" value="update">

</form>
</body>
</html>
<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/update.blade.php ENDPATH**/ ?>