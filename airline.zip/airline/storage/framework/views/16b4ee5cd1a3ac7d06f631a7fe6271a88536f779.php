<html>
<head>
<title></title>
</head>
<body>
<form action="users" method="post">
    <input type="text" name="username" placeholder="username"><br>
    <input type="password" name="password" placeholder="password"><br>
    <input type="submit" value="submit">
 </form>
</bidy>
</html><?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/login.blade.php ENDPATH**/ ?>