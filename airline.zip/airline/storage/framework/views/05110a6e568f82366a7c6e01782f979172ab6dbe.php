<!--- 
@function:register view
@author:Radhika Jaladharan
@date:10/03/2021
@module:user
---->


<form action="registerupdate/" method="get">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <input type="hidden" name="id" value="<?php echo e($users->id); ?>"> 
Name:<input type="text" name="firstname" value="<?php echo e($users->firstname); ?>"></br></br>
Lastname:<input type="text" name="lastname" value="<?php echo e($users->lastname); ?>"></br></br>
Age:<input type="text" name="age"value="<?php echo e($users->age); ?>"></br></br>
Gender:<input type="text" name="gender" value="<?php echo e($users->gender); ?>"></br></br>
Address:<input type="text" name="address" value="<?php echo e($users->address); ?>"></br></br>
Phone:<input type="text" name="phone"value="<?php echo e($users->phone); ?>"></br></br>
Email:<input type="text" name="email"value="<?php echo e($users->email); ?>"></br></br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<input type="submit" name="btn" value="update">


</form><?php /**PATH C:\Users\hp\laravel\Aireline_laravel\airline\resources\views/registerview_update.blade.php ENDPATH**/ ?>