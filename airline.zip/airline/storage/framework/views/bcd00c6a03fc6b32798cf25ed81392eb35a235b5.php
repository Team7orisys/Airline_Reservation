<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="style.css">
    
</head>
<style>
.error{
    color:red;
}
</style>



<body>
<h1>REGISTRATION</h1>
<form action="insert" method="get">
<?php echo csrf_field(); ?>
<div class="result danger">
<?php if(Session::get('sucess')): ?>
<div class="sucess bg-info">
<?php echo e(Session::get('sucess')); ?>

</div>
<?php endif; ?>


<?php if(Session::get('fail')): ?>
<div class="alert.alert-dainger">
<?php echo e(Session::get('fail')); ?>

</div>
<?php endif; ?>
</div>
<div class="form-group">
<span class="error">
<label for="exampleInputName"></label>
    <input type="text" class="form-control" id="exampleInputName" aria-describedby="emailHelp"  name="firstname" placeholder="firstname" value="<?php echo e(old('firstname')); ?>"><br><br>
    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>
    <div class="form-group">
    <span class="error">
    <label for="exampleInputEmail1"></label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="lastname" placeholder="lastname"><br><br>
    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>
    
    

    <div class="form-group">
    <span class="error">
    <label for="exampleInputPass"></label>
    <input type="text" class="form-control" id="exampleInputPass" aria-describedby="emailHelp" name="age" placeholder="age"><br><br>
    <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>

    <div class="mb-3">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input class="form-check-input" name="gender" type="radio" value="female" id=female >
      <label class="form-check-label " for=female value="female">female</label>
     &nbsp;&nbsp;&nbsp;&nbsp; <input class="form-check-input" name="gender" type="radio" value="male" id="male ">
    <label class="form-check-label " for=male value="male">male</label>
    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
</div>

    <div class="form-group">
    <span class="error">
    <label for="exampleInputPass"></label>
    <input type="text" class="form-control" id="exampleInputPass" aria-describedby="emailHelp" name="address" placeholder="address"><br><br>
    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>

    <div class="form-group">
    <span class="error">
    <label for="exampleInputPass"></label>
    <input type="text" class="form-control" id="exampleInputPass" aria-describedby="emailHelp" name="phone" placeholder="phone"><br><br>
    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>

    <div class="form-group">
    <span class="error">
    <label for="exampleInputPass"></label>
    <input type="email" class="form-control" id="exampleInputPass" aria-describedby="emailHelp" name="email" placeholder="email"><br><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>
    <div class="form-group">
    <span class="error">
    <label for="exampleInputPass"></label>
    <input type="password" class="form-control" id="exampleInputPass" aria-describedby="emailHelp" name="password" placeholder="password"><br><br>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
    </div></span>
    <input type="submit" value="register">
    
    <a href="login">login</a>
 </form>
</bidy>
</html><?php /**PATH C:\Users\Enter-Lab\Desktop\Aireline_laravel\airline\resources\views/registeruser.blade.php ENDPATH**/ ?>