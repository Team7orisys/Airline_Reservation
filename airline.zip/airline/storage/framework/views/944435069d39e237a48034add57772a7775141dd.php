<!----
@function:update flight
@author:Rubiya AS
@date:10/03/2021
@module:admin--->

<form action="/editnoti" method="post">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($data->id); ?>">

Notification:<input type="text" name="notification" value="<?php echo e($data->notification); ?>"></br></br>
Fid:<input type="text" name="fid"value="<?php echo e($data->fid); ?>"></br></br>
Date:<input type="text" name="date"value="<?php echo e($data->date); ?>"></br></br>


<input type="submit" name="btn" value="update">


</form><?php /**PATH C:\Users\hp\laravel\Aireline_laravel\airline\resources\views/update_notification.blade.php ENDPATH**/ ?>