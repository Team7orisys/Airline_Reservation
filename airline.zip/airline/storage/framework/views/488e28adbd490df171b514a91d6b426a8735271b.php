<!----
@function:update flight
@author:Rubiya AS
@date:10/03/2021
@module:admin--->

<form action="/edit" method="post">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
Company name:<input type="text" name="cname" value="<?php echo e($data->cname); ?>"></br></br>
Flightid:<input type="text" name="flightid" value="<?php echo e($data->flightid); ?>"></br></br>
From:<input type="text" name="flyfrom"value="<?php echo e($data->flyfrom); ?>"></br></br>
To:<input type="text" name="flyto" value="<?php echo e($data->flyto); ?>"></br></br>
Departure time:<input type="text" name="dtime"value="<?php echo e($data->dtime); ?>"></br></br>
Arival time:<input type="text" name="atime" value="<?php echo e($data->atime); ?>"></br></br>
Econnomic seat:<input type="text" name="eseat"value="<?php echo e($data->eseat); ?>"></br></br>
Business seat:<input type="text" name="bseat" value="<?php echo e($data->bseat); ?>"></br></br>
Firstclass seat:<input type="text" name="fseat"value="<?php echo e($data->fseat); ?>"></br></br>
Date:<input type="text" name="date"value="<?php echo e($data->date); ?>"></br></br>
Econnomic cost:<input type="text" name="ecost"value="<?php echo e($data->ecost); ?>"></br></br>
Business cost:<input type="text" name="bcost" value="<?php echo e($data->bcost); ?>"></br></br>
Firstclass cost:<input type="text" name="fcost"value="<?php echo e($data->fcost); ?>"></br></br>


<input type="submit" name="btn" value="update">


</form><?php /**PATH C:\Users\hp\laravel\Aireline_laravel\airline\resources\views/updateflight.blade.php ENDPATH**/ ?>