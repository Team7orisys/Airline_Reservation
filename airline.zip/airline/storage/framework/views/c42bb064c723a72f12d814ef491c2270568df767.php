<html>
<head>
</head>
<body>
<form action="" method="get">
<h1>PROFILE PAGE</h1>
<a href="log">LOGOUT</a>

hello <?php echo e(session('user')); ?>


</body>
</html><?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/profile.blade.php ENDPATH**/ ?>