<html>
<head>
<title></title>
</head>
<body>
<h1>LOGIN FORM</h1>
<form action="session" method="get">
    <input type="text" name="username" placeholder="username"><br><br>
    <input type="password" name="password" placeholder="password"><br><br>
    <input type="submit" value="submit">
 </form>
</bidy>
</html><?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/loginform.blade.php ENDPATH**/ ?>