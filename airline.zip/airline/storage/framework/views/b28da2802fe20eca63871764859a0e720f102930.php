<h1>welcome page</h1>
<a href="about">about</a>
<a href="contact">contact</a><?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/aboutlink.blade.php ENDPATH**/ ?>