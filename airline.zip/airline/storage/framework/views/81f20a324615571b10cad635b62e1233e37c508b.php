<html>
<head>
<title></title>
</head>
<style>
table,td,tr{border:1px solid;}
</style>
<body>
<table>
<tr>
<td>id</td>
<td>member_name</td>
<td>email</td>
<td>address</td>
<td colspan="2">action</td>
</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($item['id']); ?></td>
<td><?php echo e($item['member_name']); ?></td>
<td><?php echo e($item['email']); ?></td>
<td><?php echo e($item['address']); ?></td>

<td><a href="<?php echo e("delete/".$item['id']); ?>">delete</a></td>
<td><a href="<?php echo e("update/".$item['id']); ?>">update</a></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>

<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/list.blade.php ENDPATH**/ ?>