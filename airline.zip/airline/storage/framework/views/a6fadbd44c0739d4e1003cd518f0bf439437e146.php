<!----
@function:update airport
@author:Mahima S
@date:10/03/2021
@module:admin--->

<form action="/editairport" method="post">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
name:<input type="text" name="aname" value="<?php echo e($data->aname); ?>"></br></br>
abbrevation:<input type="text" name="abbrevation" value="<?php echo e($data->abbrevation); ?>"></br></br>
city:<input type="text" name="city"value="<?php echo e($data->city); ?>"></br></br>
state:<input type="text" name="state" value="<?php echo e($data->state); ?>"></br></br>
Pincode:<input type="text" name="pincode" value="<?php echo e($data->pincode); ?>"></br></br>

timezone:<input type="text" name="timezone"value="<?php echo e($data->timezone); ?>"></br></br>



<input type="submit" name="btn" value="update">


</form><?php /**PATH C:\Users\hp\laravel\Aireline_laravel\airline\resources\views/updateairport.blade.php ENDPATH**/ ?>