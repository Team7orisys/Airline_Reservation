<!DOCTYPE html>
<html>
<head>
<style>
</style>
</head>
<body>
<form action="/edit" method="post">

<?php echo csrf_field(); ?>
<h1> update<h1>
<input type ="hidden" name="id" placeholder="username" value="<?php echo e($data->id); ?>"><br>

<input type ="text" name="productname" placeholder="productname" value="<?php echo e($data->productname); ?>"><br>

<input type ="text" name="price" placeholder="price" value="<?php echo e($data->price); ?>"> <br>

<input type="text" name="quantity" placeholder="quantity" value="<?php echo e($data->quantity); ?>"><br>

<input type="submit"  name="update" value="update">

</form>
</body>
</html>
<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/updateproduct.blade.php ENDPATH**/ ?>