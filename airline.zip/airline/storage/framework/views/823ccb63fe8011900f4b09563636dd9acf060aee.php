<html>
<head>
<title></title>
</head>
<style>
table,td,tr{border:1px solid;}
</style>
<body>
<table>
<tr>
<td>id</td>
<td>productname</td>
<td>price</td>
<td>quantity</td>
<td>Action</td>
<td colspan="2">action</td>
</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($item['id']); ?></td>
<td><?php echo e($item['productname']); ?></td>
<td><?php echo e($item['price']); ?></td>
<td><?php echo e($item['quantity']); ?></td>

<td><a href="<?php echo e("delete/".$item['id']); ?>">delete</a></td>
<td><a href="<?php echo e("update/".$item['id']); ?>">update</a></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\Users\Enter-Lab\Desktop\laraval\example-app\resources\views/tableview.blade.php ENDPATH**/ ?>